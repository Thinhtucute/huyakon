package com.example.huyakon.domain.model

/** A screenshot saved to disk. Plain Kotlin so the domain layer stays free of android.* types. */
data class Capture(
    val path: String,
    val byteCount: Long,
    val width: Int,
    val height: Int
)