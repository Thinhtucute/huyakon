package com.example.huyakon.platform.overlay

import android.content.Context
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button

/** Floating button drawn over other apps. Milestone 1 uses a plain View; Compose comes later. */
class OverlayFabController(
    private val context: Context,
    private val onTap: () -> Unit,
) {
    private val windowManager = context.getSystemService(WindowManager::class.java)
    private var fab: View? = null

    fun show() {
        if (fab != null) return
        val button = Button(context).apply {
            text = "訳"
            setOnClickListener { onTap() }
        }
        val params = WindowManager.LayoutParams(
            64.dp(), 64.dp(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            x = 16.dp()
        }
        windowManager.addView(button, params)
        fab = button
    }

    /** Hidden (not removed) while capturing so the screenshot does not contain the FAB. */
    fun setVisible(visible: Boolean) {
        fab?.visibility = if (visible) View.VISIBLE else View.INVISIBLE
    }

    fun remove() {
        fab?.let(windowManager::removeView)
        fab = null
    }

    private fun Int.dp() = (this * context.resources.displayMetrics.density).toInt()
}
