package com.example.huyakon.data.remote

import com.example.huyakon.data.remote.dto.AnalysisDto
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.job
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.add
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.putJsonArray
import okhttp3.Call
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import java.io.IOException

class SpaceApi(
    private val client: OkHttpClient,
    baseUrl: String,
    private val json: Json = Json { ignoreUnknownKeys = true },
) {
    private val callUrl = "${baseUrl.trimEnd('/')}/gradio_api/call/analyze_b64"

    suspend fun analyze(
        jpegBase64: String,
        lang: String = "ja",
        proximitySpeakers: Boolean = true,
    ): AnalysisDto = readResult(startCall(jpegBase64, lang, proximitySpeakers))

    private suspend fun startCall(jpegBase64: String, lang: String, proximity: Boolean): String {
        val body = buildJsonObject {
            putJsonArray("data") {
                add(jpegBase64)
                add(lang)
                add(proximity)
            }
        }.toString().toRequestBody(JSON_MEDIA_TYPE)
        val request = Request.Builder().url(callUrl).post(body).build()

        return execute(client.newCall(request)) { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw IOException("Space returned HTTP ${response.code}: ${text.take(200)}")
            }
            json.parseToJsonElement(text).jsonObject["event_id"]?.jsonPrimitive?.content
                ?: throw IOException("The Space reply had no event_id")
        }
    }

    private suspend fun readResult(eventId: String): AnalysisDto {
        val request = Request.Builder().url("$callUrl/$eventId").get().build()

        return execute(client.newCall(request)) { response ->
            if (!response.isSuccessful) throw IOException("Space returned HTTP ${response.code}")
            val source = response.body?.source() ?: throw IOException("Empty reply from the Space")

            var event: String? = null
            var result: AnalysisDto? = null
            while (result == null) {
                val line = source.readUtf8Line() ?: break
                when {
                    line.startsWith("event:") -> event = line.substringAfter(':').trim()
                    line.startsWith("data:") -> {
                        val data = line.substringAfter(':').trim()
                        when (event) {
                            "complete" -> result = parseResult(data)
                            "error" -> throw IOException("Space error: $data")
                            // "heartbeat" and other events are ignored
                        }
                    }
                }
            }
            result ?: throw IOException("The Space closed the stream without a result")
        }
    }

    private fun parseResult(data: String): AnalysisDto {
        val first = json.parseToJsonElement(data).jsonArray.firstOrNull()
            ?: throw IOException("The Space returned an empty result")
        return json.decodeFromJsonElement(AnalysisDto.serializer(), first)
    }

    private suspend fun <T> execute(call: Call, read: (Response) -> T): T = withContext(Dispatchers.IO) {
        val handle = coroutineContext.job.invokeOnCompletion { cause ->
            if (cause != null) call.cancel()
        }
        try {
            call.execute().use(read)
        } finally {
            handle.dispose()
        }
    }

    private companion object {
        val JSON_MEDIA_TYPE = "application/json".toMediaType()
    }
}