package com.example.huyakon.domain

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Single source of truth for the pipeline state. The service writes to it and the UI observes it,
 * so the UI sees the latest state even if the Activity was stopped while the capture happened.
 */
class PipelineStateHolder {
    private val _state = MutableStateFlow<PipelineState>(PipelineState.Idle)
    val state: StateFlow<PipelineState> = _state.asStateFlow()

    fun update(newState: PipelineState) {
        _state.value = newState
    }
}
