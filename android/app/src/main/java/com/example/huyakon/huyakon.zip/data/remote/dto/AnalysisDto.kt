package com.example.huyakon.data.remote.dto

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
@Serializable
data class AnalysisDto(
    val image: ImageDto,
    val texts: List<TextDto> = emptyList(),
    val script: List<ScriptLineDto> = emptyList(),
)

@Serializable
data class ImageDto(val width: Int, val height: Int)

@Serializable
data class TextDto(val id: Int, val bbox: List<Float>)

@Serializable
data class ScriptLineDto(
    val order: Int,
    @SerialName("text_id") val textId: Int,
    val text: String,
    val role: String,
    @SerialName("maybe_sfx") val maybeSfx: Boolean = false,
    val speaker: String? = null,
    @SerialName("speaker_confidence") val speakerConfidence: String? = null,
)