package com.example.huyakon.data.remote

object SpaceConfig {
    const val BASE_URL = "https://thinhtucute-huyakon-magiv3.hf.space"
}